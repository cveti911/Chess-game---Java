package chess;


//This class is partially implemented. Some methods need to have their body written, some other are fine as they are and other may need to be extended. 

public class Board {
	private static Square [][] board = new Square[8][8];

	public Board(){
		for (int i=0; i<board[0].length; i++){
			for (int j=0; j<board[1].length; j++)
					board[i][j]=new Square(i,j);
		}		
	}	

	public static Square[][] getBoard(){
		return board;
	}
	
	public void initialisePieces(){

		PieceColour b = PieceColour.BLACK;
		PieceColour w = PieceColour.WHITE;

		board[0][0].setPiece(new Rook(b));
		board[0][1].setPiece(new Knight(b));
		board[0][2].setPiece(new Bishop(b));
		board[0][3].setPiece(new Queen(b));
		board[0][4].setPiece(new King(b));
		board[0][5].setPiece(new Bishop(b));
		board[0][6].setPiece(new Knight(b));
		board[0][7].setPiece(new Rook(b));

		for (int i= 0; i<8; i++){
			board[1][i].setPiece(new Pawn(b));
		}

		board[7][0].setPiece(new Rook(w));
		board[7][1].setPiece(new Knight(w));
		board[7][2].setPiece(new Bishop(w));
		board[7][3].setPiece(new Queen(w));
		board[7][4].setPiece(new King(w));
		board[7][5].setPiece(new Bishop(w));
		board[7][6].setPiece(new Knight(w));
		board[7][7].setPiece(new Rook(w));

		for (int i= 0; i<8; i++){
			board[6][i].setPiece(new Pawn(w));
		}

	}
	
	public void printBoard(){
		System.out.print("\n  a b c d e f g h \n");
		System.out.print("  -----------------\n");
		String wsp=" ";String bar="|";
		
		for (int i=0; i<board[0].length; i++){
			int row=i+1;
				for (int j=0; j<board[1].length; j++){
					if ((j==0) && board[i][j].hasPiece())
						System.out.print(row+" "+board[i][j].getPiece().getSymbol());	
					else if ((j==0) && !board[i][j].hasPiece())
						System.out.print(row+"  " );
					else if (board[i][j].hasPiece())					
						System.out.print("|" +board[i][j].getPiece().getSymbol());					
					else					
						System.out.print("| ");		
				}				
				System.out.print("  "+row+"\n");
		}
		System.out.print("  -----------------");
		System.out.print("\n  a b c d e f g h \n");
	
	}


	public boolean movePiece(int i0, int j0, int i1, int j1, Piece p){
		boolean check = (board[i1][j1].getPiece() instanceof King);
		board[i0][j0].removePiece();
		board[i1][j1].removePiece();
		board[i1][j1].setPiece(p);
		if (check == true) return true;
		return false;
	}




	public void setPiece(int iIn, int jIn, Piece p){
		board[iIn][jIn].setPiece(p);

	}
	
	public Piece getPiece(int iIn, int jIn){
		return (board[iIn][jIn].getPiece());
	}
	

	public boolean hasPiece(int i, int j){		
		if(board[i][j].hasPiece() == false) return false;
		return true;
	}

}
