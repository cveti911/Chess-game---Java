package chess;

public class King extends Piece{
	King(PieceColour colourIn){
		colour = colourIn;
		if (colour == PieceColour.WHITE) setSymbol(Character.toString((char)'\u2654'));
		if (colour == PieceColour.BLACK) setSymbol(Character.toString((char)'\u265A'));
	}

	public boolean isLegitMove(int rowOld, int columnOld, int rowNew, int columnNew){
		if((Math.abs(columnOld - columnNew) > 1) || (Math.abs(rowOld - rowNew) > 1)) return false;
		if((rowNew == rowOld) && (columnNew == columnOld)) return false;
		if (Board.getBoard()[rowNew][columnNew].hasPiece() == true){
				if(Board.getBoard()[rowNew][columnNew].getPiece().getColour() == colour){
					return false;
				}else{
					
					return true;
				}
			}else{

				return true;
			}		
		
	}
	
}
