package chess;

public enum PieceColour {
	WHITE,BLACK;
}
