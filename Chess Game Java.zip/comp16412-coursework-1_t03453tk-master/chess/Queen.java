package chess;

public class Queen extends Piece{
	Queen(PieceColour colourIn){
		colour = colourIn;
		if (colour == PieceColour.WHITE) setSymbol(Character.toString((char)'\u2655'));
		if (colour == PieceColour.BLACK) setSymbol(Character.toString((char)'\u265B'));

	}

	public boolean isLegitMove(int rowOld, int columnOld, int rowNew, int columnNew){
		//rook-kind moves
		if((rowOld == rowNew) && (columnOld == columnNew)) return false;
		if((rowOld == rowNew) && (columnNew != columnOld)){
			for(int i = 1; i < Math.abs(columnNew - columnOld); i++){
				if(columnNew < columnOld) i =  -i;
				if(Board.getBoard()[rowOld][columnOld + i].hasPiece() == true) return false;
				if(columnNew < columnOld) i =  -i;

			}	
			if (Board.getBoard()[rowNew][columnNew].hasPiece() == true){
				if(Board.getBoard()[rowNew][columnNew].getPiece().getColour() == colour){
					return false;
				}else{
							
					return true;
				}
			}else{

				return true;
			}		

		}

		if((rowOld != rowNew) && (columnNew == columnOld)){
			for(int i = 1; i < Math.abs(rowNew - rowOld); i++){
				if(rowNew < rowOld) i =  -i; 
				if(Board.getBoard()[rowOld + i][columnOld].hasPiece() == true) return false;
				if(rowNew < rowOld) i =  -i;
			}
			if (Board.getBoard()[rowNew][columnNew].hasPiece() == true){
				if(Board.getBoard()[rowNew][columnNew].getPiece().getColour() == colour){
					return false;
				}else{
							
					return true;
				}
			}else{

				return true;
			}		
		}

		//bishop-kind moves
		if((Math.abs(rowNew - rowOld) == Math.abs(columnNew - columnOld)) && (Math.abs(rowNew - rowOld) != 0)){
			for (int i = 1; i < Math.abs(rowNew - rowOld); i++){
	
				int rowMove = i;
				int columnMove = i;
				if(rowOld > rowNew) rowMove = -i;
				if(columnOld > columnNew) columnMove = -i;
				if(Board.getBoard()[rowOld + rowMove][columnOld + columnMove].hasPiece() == true) return false;
			}
			if (Board.getBoard()[rowNew][columnNew].hasPiece() == true){
				if(Board.getBoard()[rowNew][columnNew].getPiece().getColour() == colour){
					 return false;
				}else{
					return true;
				}
			}else{
				return true;
			}
			

		}
	return false;
		
	}
}
