package chess;
import java.io.Console;

public class Game {
	private static boolean gameEnd=false;

	public Game(){
		Board b = new Board();
		b.initialisePieces();
		b.printBoard();
		boolean whiteturn = true;
		Console con = System.console();
		PieceColour currColour = PieceColour.WHITE;
		int rowOld, rowNew, columnOld, columnNew;
		boolean kingCheck = false;
		while ((!gameEnd)  && (!kingCheck)){
			if(whiteturn){
				System.out.println("\n" + "-----------Whites turn-----------");
				currColour = PieceColour.WHITE;
			}else{
				System.out.println("\n" + "-----------Blacks turn-----------");
				currColour = PieceColour.BLACK;
			
			}
			boolean validityCheck = false;
			CheckInput a = new CheckInput();

			while(!validityCheck){
				//checking origin
				String origin = con.readLine("Enter origin: ");
				if ((a.checkCoordinateValidity(origin) == false) || (origin.equals("END"))){
					if(origin.equals("END")){
						gameEnd = true;
						break;
					}
					System.out.print("Invalid orgin. ");
					continue;
				}
				if((b.hasPiece(Character.getNumericValue(origin.charAt(0)) - 1, Character.getNumericValue(origin.charAt(1)) - 10) == false) || (origin.equals("END"))){
					if(origin.equals("END")){
						gameEnd = true;
						break;
					}					
					System.out.print("Invalid orgin. ");
					continue;
				}

				if((b.getPiece(Character.getNumericValue(origin.charAt(0)) - 1, Character.getNumericValue(origin.charAt(1)) - 10).getColour() != currColour) || (origin.equals("END"))){
					
					if(origin.equals("END")){
						gameEnd = true;
						break;
					}					
					System.out.print("Invalid orgin. ");
					continue;
				}

				rowOld = Character.getNumericValue(origin.charAt(0)) - 1;
				columnOld = Character.getNumericValue(origin.charAt(1)) - 10;
				
				//cheking destination
				String destination = con.readLine("Enter destination: ");
				
				while((a.checkCoordinateValidity(destination) == false) || (origin.equals("END"))) destination = con.readLine("Invalid destination. Enter destination again: ");
				rowNew = Character.getNumericValue(destination.charAt(0)) - 1;
				columnNew = Character.getNumericValue(destination.charAt(1)) - 10;
				if(b.getBoard()[rowOld][columnOld].getPiece().isLegitMove(rowOld, columnOld, rowNew, columnNew) == false){
					System.out.println("This is not a legitimate move. Try again:");
					continue;
				}else{
					//moving and checking if king is captured
					kingCheck = b.movePiece(rowOld, columnOld, rowNew, columnNew, (b.getBoard()[rowOld][columnOld].getPiece()));				
					validityCheck = true;

				}				

			}

			if ((!gameEnd)  && (!kingCheck)) b.printBoard();			
			if(whiteturn){
				whiteturn = false;
			}else{
				whiteturn = true;
			}

		}	
		//checking why the game ended
		if (gameEnd == true){
			if(!whiteturn){
				System.out.println("WHITES resigned.");
			}else{
				System.out.println("BLACKS resigned.");
			}
		}
		if (kingCheck == true){
			if(!whiteturn){
				System.out.println("\n"+ "\n"+"WHITES WON.");
			}else{
				System.out.println("\n"+ "\n"+"BLACKS WON.");
			}
			b.printBoard();				
		}


	}
	
	public static void main (String args[]){
		Game g  = new Game();
	}
}
