package chess;

public class Rook extends Piece{
	Rook(PieceColour colourIn){
		colour = colourIn;

		if (colour == PieceColour.WHITE) setSymbol(Character.toString((char) '\u2656'));
		if (colour == PieceColour.BLACK) setSymbol(Character.toString((char) '\u265C'));
	}
	public boolean isLegitMove(int rowOld, int columnOld, int rowNew, int columnNew){
		
		if(!((rowOld == rowNew) || (columnOld == columnNew))) return false;
			
		if((rowOld == rowNew) && (columnNew != columnOld)){
			for(int i = 1; i < Math.abs(columnNew - columnOld); i++){
				if(columnNew < columnOld) i =  -i; 
				if (Board.getBoard()[rowOld] [columnOld + i].hasPiece() == true) return false;
				if(columnNew < columnOld) i =  -i;			
			}
		}	
		if((rowOld != rowNew) && (columnNew == columnOld)){
			for(int i = 1; i < Math.abs(rowNew - rowOld); i++){
				if(rowNew < rowOld) i =  -i; 
				if(Board.getBoard()[rowOld + i][columnOld].hasPiece() == true) return false;
				if(rowNew < rowOld) i =  -i; 				
			}
		}
		
		if (Board.getBoard()[rowNew][columnNew].hasPiece() == true){
			if(Board.getBoard()[rowNew][columnNew].getPiece().getColour() == colour){
				return false;
			}else{
				return true;
			}
		}else{

			return true;
		}
	
	}
}
