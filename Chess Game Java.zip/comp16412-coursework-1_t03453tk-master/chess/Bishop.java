package chess;

public class Bishop extends Piece{
	Bishop(PieceColour colourIn){
		colour = colourIn;
		if (colour == PieceColour.WHITE) setSymbol(Character.toString((char)'\u2657'));
		if (colour == PieceColour.BLACK) setSymbol(Character.toString((char)'\u265D'));
	}
	
	public boolean isLegitMove(int rowOld, int columnOld, int rowNew, int columnNew){
		if(Math.abs(rowNew - rowOld) != Math.abs(columnNew - columnOld)) return false;
		if(Math.abs(rowNew - rowOld) == 0) return false;
		

		for (int i = 1; i < Math.abs(rowNew - rowOld); i++){
			int rowMove = i;
			int columnMove = i;
			if(rowOld > rowNew) rowMove = -i;
			if(columnOld > columnNew) columnMove = -i;
			if(Board.getBoard()[rowOld + rowMove][columnOld + columnMove].hasPiece() == true) return false;
			}


		if (Board.getBoard()[rowNew][columnNew].hasPiece() == true){
				if(Board.getBoard()[rowNew][columnNew].getPiece().getColour() == colour){
					return false;
				}else{
					
					return true;
				}
			}else{

				return true;
		}	

	}
}
