package chess;

public class Pawn extends Piece{	
	Pawn(PieceColour colourIn){
		colour = colourIn;
		if (colour == PieceColour.WHITE) setSymbol(Character.toString((char)'\u2659'));
		if (colour == PieceColour.BLACK) setSymbol(Character.toString((char)'\u265F'));
	}

	public boolean isLegitMove(int rowOld, int columnOld, int rowNew, int columnNew){
		if((rowNew >= rowOld) && (colour == PieceColour.WHITE))return false;
		
		if((rowNew <= rowOld) && (colour == PieceColour.BLACK))return false;
		
		if ((rowOld == 1) && (rowNew == 3) && (columnOld == columnNew) && (colour == PieceColour.BLACK)){
			if (Board.getBoard()[2][columnNew].hasPiece() == true) return false;
			if (Board.getBoard()[rowNew][columnNew].hasPiece() == true) return false;
			
			return true;
		}

		if ((rowOld == 6) && (rowNew == 4) && (columnOld == columnNew) && (colour == PieceColour.WHITE)){
			if (Board.getBoard()[5][columnNew].hasPiece() == true) return false;
			if (Board.getBoard()[rowNew][columnNew].hasPiece() == true) return false;
			return true;
		}
		if(Math.abs(rowNew - rowOld) > 1) return false;
		if((columnNew == columnOld) && (Board.getBoard()[rowNew][columnNew].hasPiece() == true)) return false;
		if((Math.abs(columnOld - columnNew) == 1) && (Board.getBoard()[rowNew][columnNew].hasPiece() == true)){
			if(Board.getBoard()[rowNew][columnNew].getPiece().getColour() == colour){
				return false;
			}else{
				return true;
			}
		}
		if((Math.abs(columnOld - columnNew) == 1) && !(Board.getBoard()[rowNew][columnNew].hasPiece() == true)) return false;
		

		return true;	

	}
}
