package chess;

public class CheckInput {
	
	
	public boolean checkCoordinateValidity(String input){
		boolean check = false;
		if(input.length() != 2) return false;
		char charNumber = input.charAt(0);
		char charLetter = input.charAt(1);
		if(((int) charNumber >= 49) && ((int) charNumber <= 56) && ((int) charLetter >= 97) && ((int) charLetter <= 104)){
			return true;
		}else{
			return false;
		}

		

	}
}
