package chess;


public class Knight extends Piece{
	Knight(PieceColour colourIn){
		colour = colourIn;
		if (colour == PieceColour.WHITE) setSymbol(Character.toString((char)'\u2658'));
		if (colour == PieceColour.BLACK) setSymbol(Character.toString((char)'\u265E'));
	}


	public boolean isLegitMove(int rowOld, int columnOld, int rowNew, int columnNew){
		
		boolean check = false;
		if ((Math.abs(rowOld - rowNew) == 2) && (Math.abs(columnOld - columnNew) == 1)){

			check =  true;
		}
		if ((Math.abs(columnOld - columnNew) == 2) && (Math.abs(rowOld - rowNew) == 1)){
			

			check = true;
		}

		if ((Board.getBoard()[rowNew][columnNew].hasPiece() == false) && (check == true)){
			
			return true;

		}
		if ((Board.getBoard()[rowNew][columnNew].hasPiece() == true) && (check == true)){
			if(Board.getBoard()[rowNew][columnNew].getPiece().getColour() == colour){
				return false;
			}else{
				
				return true;
			}


		}
		return false;


		
	}
}
