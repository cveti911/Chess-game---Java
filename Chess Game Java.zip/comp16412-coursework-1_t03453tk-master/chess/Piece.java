package chess;

public abstract class Piece{
	private int row;
	private int column;
	private String symbol;
	protected PieceColour colour;
	public Piece(){}
	public String getSymbol(){

		return symbol;
	}
	public void setSymbol(String symbolIn){
		symbol = symbolIn;

	}
	public PieceColour getColour(){

		return colour;
	}

	public void updateCoordinates(int rowIn, int columnIn){
		row = rowIn;
		column = columnIn;

	}

	public abstract boolean isLegitMove(int rowOld, int columnOld, int rowNew, int columnNew);


}
